import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState, type ReactNode } from "react";

const SITE_TITLE = "Stride — Open-source Android step counter";
const SITE_DESC =
  "Stride is an open-source Material 3 Expressive step counter for Android. No ads, no accounts, no analytics — your steps never leave your device.";
const OG_IMAGE = "https://github.com/NikhilKain/stride/raw/main/docs/img1.jpg";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: SITE_TITLE },
      { name: "description", content: SITE_DESC },
      {
        name: "keywords",
        content:
          "Stride, step counter, pedometer, Android, open source, Material 3, Kotlin, Jetpack Compose, Health Connect, privacy",
      },
      { property: "og:title", content: SITE_TITLE },
      { property: "og:description", content: SITE_DESC },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { property: "og:site_name", content: "Stride" },
      { property: "og:image", content: OG_IMAGE },
      { property: "og:image:alt", content: "Stride dashboard on Android" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: SITE_TITLE },
      { name: "twitter:description", content: SITE_DESC },
      { name: "twitter:image", content: OG_IMAGE },
      { name: "theme-color", content: "#00786A" },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "SoftwareApplication",
          name: "Stride",
          operatingSystem: "Android 8.0+",
          applicationCategory: "HealthApplication",
          description: SITE_DESC,
          offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
          license: "https://www.gnu.org/licenses/gpl-3.0.html",
          url: "https://github.com/NikhilKain/stride",
        }),
      },
    ],
  }),
});


const RELEASE_URL = "https://github.com/NikhilKain/stride/releases/latest";
const REPO_URL = "https://github.com/NikhilKain/stride";
const LOGO = "https://github.com/NikhilKain/stride/raw/main/docs/logo.png";
const SHOTS = [
  { src: "https://github.com/NikhilKain/stride/raw/main/docs/img1.jpg", label: "Dashboard" },
  { src: "https://github.com/NikhilKain/stride/raw/main/docs/img2.jpg", label: "Insights" },
  { src: "https://github.com/NikhilKain/stride/raw/main/docs/img3.jpg", label: "History" },
  { src: "https://github.com/NikhilKain/stride/raw/main/docs/img4.jpg", label: "Theming" },
  { src: "https://github.com/NikhilKain/stride/raw/main/docs/img5.jpg", label: "Share card" },
];

type Theme = "system" | "light" | "dark";

function useTheme() {
  const [theme, setTheme] = useState<Theme>("system");
  useEffect(() => {
    const saved = (localStorage.getItem("stride-theme") as Theme) || "system";
    setTheme(saved);
  }, []);
  useEffect(() => {
    const mql = window.matchMedia("(prefers-color-scheme: dark)");
    const apply = () => {
      const dark = theme === "dark" || (theme === "system" && mql.matches);
      document.documentElement.classList.toggle("dark", dark);
    };
    apply();
    localStorage.setItem("stride-theme", theme);
    if (theme === "system") {
      mql.addEventListener("change", apply);
      return () => mql.removeEventListener("change", apply);
    }
  }, [theme]);
  return [theme, setTheme] as const;
}

function Reveal({ children, delay = 0 }: { children: ReactNode; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (es) => es.forEach((e) => e.isIntersecting && (setShown(true), io.disconnect())),
      { rootMargin: "-40px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div
      ref={ref}
      style={{ animationDelay: `${delay}ms` }}
      className={shown ? "stride-rise" : "opacity-0"}
    >
      {children}
    </div>
  );
}

function ThemeToggle() {
  const [theme, setTheme] = useTheme();
  const next: Record<Theme, Theme> = { system: "light", light: "dark", dark: "system" };
  const label = { system: "Sys", light: "Lgt", dark: "Drk" }[theme];
  return (
    <button
      onClick={() => setTheme(next[theme])}
      className="font-mono-tech text-xs uppercase text-text-dim hover:text-text px-2 py-1 border border-border rounded-md transition-colors"
      aria-label={`Theme: ${theme}`}
    >
      {label}
    </button>
  );
}

function PhoneFrame({
  src,
  alt,
  className = "",
  style,
}: {
  src: string;
  alt: string;
  className?: string;
  style?: React.CSSProperties;
}) {
  return (
    <div
      className={`phone-tilt relative rounded-[2.2rem] border border-border bg-surface p-2 shadow-[0_30px_80px_-30px_rgba(0,0,0,0.5)] hover:shadow-[0_40px_100px_-30px_rgba(0,120,106,0.35)] ${className}`}
      style={style}
    >
      <div className="overflow-hidden rounded-[1.7rem] bg-bg">
        <img src={src} alt={alt} loading="lazy" className="block w-full h-auto" />
      </div>
    </div>
  );
}

const FEATURES = [
  {
    n: "01",
    title: "Counting that actually works",
    body: "Foreground service, survives reboot, near-zero battery cost since the hardware counter does the work.",
  },
  {
    n: "02",
    title: "A dashboard worth opening",
    body: "Wavy ring fills as you walk, odometer rolls digit by digit, distance calibrated from your height.",
  },
  {
    n: "03",
    title: "History you can read at a glance",
    body: "Weekly bar chart and monthly calendar heatmap. Any day tappable.",
  },
  {
    n: "04",
    title: "Streaks and 14 achievements",
    body: "Each a morphing Material shape, from “First Steps” to “Ultra Walker” at 30,000 steps in a day.",
  },
  {
    n: "05",
    title: "Live Updates on Android 16",
    body: "Promoted status bar notification where supported. Tells you honestly when it isn't.",
  },
  {
    n: "06",
    title: "Theming, seriously",
    body: "Light / dark / system / AMOLED, Material You colors, four palettes, five color styles, six bundled variable fonts.",
  },
  {
    n: "07",
    title: "Backups that are just a file",
    body: "Exports to one readable JSON. No cloud.",
  },
];

const SPECS: [string, ReactNode][] = [
  ["Language", "Kotlin"],
  ["UI", "Jetpack Compose · Material 3 Expressive (1.5.0-alpha17)"],
  ["Data", "Health Connect · Room · DataStore"],
  ["Background", "Foreground service · WorkManager"],
  ["Min / target SDK", "26 / 36"],
  ["Languages", "English · Hindi"],
  ["License", "GPL-3.0"],
];

function Index() {
  const [scrolled, setScrolled] = useState(false);
  const [active, setActive] = useState<string>("top");

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 8);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  useEffect(() => {
    const ids = ["top", "features", "screens", "tech"];
    const els = ids
      .map((id) => document.getElementById(id))
      .filter((el): el is HTMLElement => !!el);
    if (!els.length) return;
    const io = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target?.id) setActive(visible.target.id);
      },
      { rootMargin: "-45% 0px -45% 0px", threshold: [0, 0.25, 0.5, 0.75, 1] },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  const handleNav = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    const el = document.getElementById(id);
    if (!el) return;
    e.preventDefault();
    el.scrollIntoView({ behavior: "smooth", block: "start" });
    history.replaceState(null, "", `#${id}`);
  };

  const navItems = [
    { id: "features", label: "Features" },
    { id: "screens", label: "Screens" },
    { id: "tech", label: "Tech" },
  ];

  return (
    <div className="min-h-screen bg-bg text-text font-sans selection:bg-accent">
      {/* NAV */}
      <header
        className={`sticky top-0 z-50 bg-bg/85 backdrop-blur-md transition-all duration-300 ${
          scrolled ? "border-b border-border" : "border-b border-transparent"
        }`}
      >
        <div className="mx-auto max-w-6xl px-5 sm:px-8 h-14 flex items-center justify-between gap-4">
          <a
            href="#top"
            onClick={(e) => handleNav(e, "top")}
            className="flex items-center gap-2 min-w-0 group"
          >
            <img
              src={LOGO}
              alt=""
              className="h-6 w-6 rounded-md transition-transform duration-500 group-hover:rotate-[18deg] group-hover:scale-110"
            />
            <span className="font-display font-semibold tracking-tight text-[15px]">Stride</span>
          </a>
          <nav className="hidden md:flex items-center gap-7 text-sm text-text-dim">
            {navItems.map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                onClick={(e) => handleNav(e, item.id)}
                data-active={active === item.id}
                className="nav-link hover:text-text"
              >
                {item.label}
              </a>
            ))}
            <a
              href={REPO_URL}
              target="_blank"
              rel="noreferrer"
              className="nav-link hover:text-text"
            >
              Source
            </a>
          </nav>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <a
              href={RELEASE_URL}
              className="hidden sm:inline-flex font-mono-tech text-xs uppercase tracking-wider bg-accent text-on-accent px-3 py-1.5 rounded-md hover:bg-accent-strong hover:-translate-y-0.5 hover:shadow-lg hover:shadow-accent/20 transition-all"
            >
              Download
            </a>
          </div>
        </div>
      </header>

      {/* HERO */}
      <section id="top" className="mx-auto max-w-6xl px-5 sm:px-8 pt-14 sm:pt-24 pb-20 sm:pb-28">
        <div className="grid lg:grid-cols-12 gap-14 lg:gap-10 items-start">
          <div className="lg:col-span-7">
            <Reveal>
              <div className="font-mono-tech text-[11px] uppercase tracking-[0.2em] text-text-faint flex items-center gap-2">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-accent stride-pulse-dot" />
                Open source · Android 8.0+
              </div>
            </Reveal>
            <Reveal delay={80}>
              <h1 className="mt-6 font-display font-semibold text-4xl sm:text-6xl lg:text-[4.5rem] leading-[1.02] stride-blur-in">
                A step counter that{" "}
                <span className="text-accent">respects your attention.</span>
              </h1>
            </Reveal>
            <Reveal delay={160}>
              <p className="mt-7 max-w-xl text-text-dim text-lg leading-relaxed">
                Counts your steps, draws them well, and otherwise leaves you alone.
                No ads, no account, no analytics — your steps never leave your device.
              </p>
            </Reveal>
            <Reveal delay={240}>
              <div className="mt-9 flex flex-wrap items-center gap-6">
                <a
                  href={RELEASE_URL}
                  className="font-mono-tech text-sm uppercase tracking-wider bg-accent text-on-accent px-5 py-3 rounded-md hover:bg-accent-strong hover:-translate-y-0.5 hover:shadow-xl hover:shadow-accent/25 active:translate-y-0 transition-all"
                >
                  Download APK
                </a>
                <a
                  href={REPO_URL}
                  className="text-sm text-text hover:text-accent transition-colors border-b border-border hover:border-accent pb-0.5 group"
                >
                  View source{" "}
                  <span className="inline-block transition-transform group-hover:translate-x-1">→</span>
                </a>
              </div>
            </Reveal>

            <Reveal delay={340}>
              <dl className="mt-14 grid grid-cols-3 border-t border-border">
                {[
                  ["GPL-3.0", "fully open source"],
                  ["0", "ads or accounts"],
                  ["14", "achievements"],
                ].map(([n, l], i) => (
                  <div
                    key={l}
                    className={`py-5 pr-4 hover-lift ${i > 0 ? "border-l border-border pl-5" : ""}`}
                  >
                    <dt className="font-mono-tech text-lg sm:text-2xl text-text">{n}</dt>
                    <dd className="mt-1 text-xs sm:text-sm text-text-faint">{l}</dd>
                  </div>
                ))}
              </dl>
            </Reveal>
          </div>


          <div className="lg:col-span-5 relative min-h-[420px] sm:min-h-[540px]">
            <Reveal delay={200}>
              <div className="relative mx-auto max-w-[380px] lg:max-w-none">
                <PhoneFrame
                  src={SHOTS[2].src}
                  alt="Stride history screen"
                  className="stride-float absolute top-6 -right-2 sm:right-6 w-[62%] opacity-90"
                  style={{ ["--r" as string]: "6deg", animationDelay: "1.2s" } as React.CSSProperties}
                />
                <PhoneFrame
                  src={SHOTS[0].src}
                  alt="Stride dashboard"
                  className="stride-float relative w-[74%] ml-0 lg:ml-4"
                  style={{ ["--r" as string]: "-3deg" } as React.CSSProperties}
                />
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* MANIFESTO */}
      <section className="border-t border-border">
        <div className="mx-auto max-w-6xl px-5 sm:px-8 py-20 sm:py-28">
          <div className="grid lg:grid-cols-12 gap-10">
            <div className="lg:col-span-3">
              <Reveal>
                <div className="font-mono-tech text-[11px] uppercase tracking-[0.2em] text-text-faint">
                  Why another step counter
                </div>
              </Reveal>
            </div>
            <div className="lg:col-span-9">
              <Reveal delay={80}>
                <p className="font-display font-medium text-2xl sm:text-3xl lg:text-4xl leading-[1.25] text-text">
                  Most of them want a login, a subscription, and permission to sell your
                  movement data.{" "}
                  <span className="text-text-dim">
                    Stride reads Health Connect when you allow it, falls back to the
                    hardware counter when you don't, and merges the two by taking
                    whichever saw more — never by adding them, so nothing is
                    double-counted.
                  </span>
                </p>
              </Reveal>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" className="border-t border-border">
        <div className="mx-auto max-w-6xl px-5 sm:px-8 py-20 sm:py-28">
          <Reveal>
            <div className="flex items-baseline justify-between mb-10">
              <h2 className="font-display font-semibold text-3xl sm:text-4xl">
                What it does
              </h2>
              <span className="font-mono-tech text-xs text-text-faint">07 features</span>
            </div>
          </Reveal>
          <ul>
            {FEATURES.map((f, i) => (
              <li key={f.n} className={`border-t border-border ${i === FEATURES.length - 1 ? "border-b" : ""}`}>
                <Reveal delay={i * 40}>
                  <div className="feature-row grid grid-cols-[auto_1fr] sm:grid-cols-[80px_1fr_1.4fr] gap-x-6 sm:gap-x-10 py-7 sm:py-8 px-2 -mx-2 rounded-md items-baseline group">
                    <div className="feature-num font-mono-tech text-sm text-accent">{f.n}</div>
                    <h3 className="font-display font-semibold text-lg sm:text-xl text-text">
                      {f.title}
                    </h3>
                    <p className="col-span-2 sm:col-span-1 mt-2 sm:mt-0 text-text-dim leading-relaxed">
                      {f.body}
                    </p>
                  </div>
                </Reveal>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* SCREENS */}
      <section id="screens" className="border-t border-border">
        <div className="mx-auto max-w-6xl px-5 sm:px-8 pt-20 sm:pt-28 pb-10">
          <Reveal>
            <div className="flex items-baseline justify-between mb-10">
              <h2 className="font-display font-semibold text-3xl sm:text-4xl">Screens</h2>
              <span className="font-mono-tech text-xs text-text-faint">Swipe →</span>
            </div>
          </Reveal>
        </div>
        <div
          className="overflow-x-auto pb-24"
          style={{ scrollSnapType: "x proximity", scrollbarWidth: "none" }}
        >
          <ul className="flex gap-6 sm:gap-8 px-5 sm:px-8 mx-auto max-w-6xl">
            {SHOTS.map((s, i) => (
              <li
                key={s.src}
                className="shrink-0 w-[68vw] sm:w-[42vw] lg:w-[24vw] max-w-[320px]"
                style={{ scrollSnapAlign: "start" }}
              >
                <PhoneFrame src={s.src} alt={s.label} />
                <div className="mt-4 flex items-baseline justify-between">
                  <span className="font-display font-medium text-text">{s.label}</span>
                  <span className="font-mono-tech text-xs text-text-faint">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* TECH SPEC */}
      <section id="tech" className="border-t border-border">
        <div className="mx-auto max-w-6xl px-5 sm:px-8 py-20 sm:py-28">
          <Reveal>
            <h2 className="font-display font-semibold text-3xl sm:text-4xl mb-10">
              Technical
            </h2>
          </Reveal>
          <dl>
            {SPECS.map(([k, v], i) => (
              <Reveal key={k} delay={i * 30}>
                <div className="grid grid-cols-1 sm:grid-cols-[220px_1fr] gap-2 sm:gap-8 py-4 border-t border-border">
                  <dt className="font-mono-tech text-xs uppercase tracking-wider text-text-faint pt-1">
                    {k}
                  </dt>
                  <dd className="text-text">{v}</dd>
                </div>
              </Reveal>
            ))}
            <div className="border-t border-border" />
          </dl>
        </div>
      </section>

      {/* CTA BAND */}
      <section className="border-t border-border">
        <div className="mx-auto max-w-6xl px-5 sm:px-8 py-20 sm:py-24">
          <Reveal>
            <div className="rounded-2xl border border-border bg-surface p-8 sm:p-14">
              <div className="grid lg:grid-cols-12 gap-8 items-end">
                <div className="lg:col-span-8">
                  <h3 className="font-display font-semibold text-3xl sm:text-4xl lg:text-5xl leading-tight">
                    Free, open, and stays that way.
                  </h3>
                  <p className="mt-5 text-text-dim max-w-2xl leading-relaxed">
                    Stride follows an open-core model. This repository is the complete
                    free edition — every feature above, forever GPL-3.0. A separate paid
                    edition adds GPS route tracking and a home-screen widget for people
                    who want them.
                  </p>
                </div>
                <div className="lg:col-span-4 flex flex-wrap gap-4 lg:justify-end">
                  <a
                    href={RELEASE_URL}
                    className="font-mono-tech text-sm uppercase tracking-wider bg-accent text-on-accent px-5 py-3 rounded-md hover:bg-accent-strong transition-colors"
                  >
                    Download APK
                  </a>
                  <a
                    href={REPO_URL}
                    className="font-mono-tech text-sm uppercase tracking-wider border border-border text-text px-5 py-3 rounded-md hover:border-accent hover:text-accent transition-colors"
                  >
                    Star on GitHub
                  </a>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-border">
        <div className="mx-auto max-w-6xl px-5 sm:px-8 py-16">
          <div className="grid sm:grid-cols-12 gap-10">
            <div className="sm:col-span-6">
              <div className="flex items-center gap-2">
                <img src={LOGO} alt="" className="h-6 w-6 rounded-md" />
                <span className="font-display font-semibold">Stride</span>
              </div>
              <p className="mt-4 text-sm text-text-dim max-w-sm">
                An open-source Material 3 Expressive step counter for Android.
                Your steps never leave your device.
              </p>
            </div>
            <div className="sm:col-span-3">
              <div className="font-mono-tech text-[11px] uppercase tracking-[0.2em] text-text-faint">
                Project
              </div>
              <ul className="mt-4 space-y-2 text-sm">
                <li><a href={REPO_URL} className="text-text hover:text-accent">Repository</a></li>
                <li><a href={RELEASE_URL} className="text-text hover:text-accent">Download</a></li>
                <li><a href={`${REPO_URL}/issues`} className="text-text hover:text-accent">Issues</a></li>
              </ul>
            </div>
            <div className="sm:col-span-3">
              <div className="font-mono-tech text-[11px] uppercase tracking-[0.2em] text-text-faint">
                Details
              </div>
              <ul className="mt-4 space-y-2 text-sm">
                <li><a href="#features" className="text-text hover:text-accent">Features</a></li>
                <li><a href="#tech" className="text-text hover:text-accent">Tech</a></li>
                <li><a href={`${REPO_URL}/blob/main/LICENSE`} className="text-text hover:text-accent">License</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-14 pt-6 border-t border-border flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between font-mono-tech text-[11px] uppercase tracking-wider text-text-faint">
            <div>© {new Date().getFullYear()} Stride · GPL-3.0</div>
            <div>
              Fonts: Nunito · Inter · Outfit · Lexend · Manrope · Space Grotesk — SIL OFL
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
